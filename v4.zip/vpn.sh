#!/bin/bash

echo "🔧 Atualizando pacotes e instalando dependências..."
apt-get update
apt-get install -y openjdk-11-jdk fuse openvpn

echo "📥 Baixando Dolphin..."
wget https://dolphin-anty-cdn.com/anty-app/dolphin-anty-linux-x86_64-latest.AppImage -O dolphin-anty.AppImage
chmod +x dolphin-anty.AppImage

echo "📥 GEBE..."
wget https://dolphin-anty-cdn.com/anty-app/dolphin-anty-linux-x86_64-latest.AppImage -O dolphin-anty.AppImage
chmod +x dolphin-anty.AppImage

echo "🌍 Selecionando país da VPN aleatoriamente..."

# Lista de países válidos (usando os sufixos dos arquivos)
COUNTRIES=("de" "nl" "dk")
SELECTED=${COUNTRIES[$RANDOM % ${#COUNTRIES[@]}]}

echo "🔀 País selecionado: $SELECTED"

OVPN_FILE="openvpn_${SELECTED}.ovpn"
CREDENTIALS_FILE="credentials_${SELECTED}"

# Verificando se os arquivos existem
if [[ ! -f "$OVPN_FILE" || ! -f "$CREDENTIALS_FILE" ]]; then
    echo "❌ Arquivo $OVPN_FILE ou $CREDENTIALS_FILE não encontrado!"
    exit 1
fi

# Adiciona a linha auth-user-pass dentro do .ovpn se não estiver presente
if ! grep -q "auth-user-pass" "$OVPN_FILE"; then
    echo "auth-user-pass $CREDENTIALS_FILE" >> "$OVPN_FILE"
fi

echo "🔌 Conectando à VPN usando $OVPN_FILE..."

# Inicia OpenVPN
openvpn --config "$OVPN_FILE" &
VPN_PID=$!

# Aguarda a inicialização
sleep 10

echo "✅ VPN iniciada. Processo OpenVPN: $VPN_PID"
